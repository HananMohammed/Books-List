<div id="remote"></div>
<?php /**PATH C:\xampp\htdocs\books_Task\resources\views/remote.blade.php ENDPATH**/ ?>